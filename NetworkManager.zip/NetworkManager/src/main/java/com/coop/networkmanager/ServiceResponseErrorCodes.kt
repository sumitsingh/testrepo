package com.coop.networkmanager

enum class ServiceResponseErrorCodes(val key: String) {
    ERROR_CODE_503("503"),
    ERROR_CODE_500("500"),
    ERROR_CODE_NO_INTERNET("10002") // Internet check
}
