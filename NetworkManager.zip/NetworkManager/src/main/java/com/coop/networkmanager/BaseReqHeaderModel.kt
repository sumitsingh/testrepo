/*
 * Created by the co-operative bank.
 * Copyright (c) 2020 . All rights reserved.
 * Last modified 4/15/20 6:40 PM
 */

package com.coop.networkmanager

import android.text.TextUtils
import com.coop.coopcore.utils.AuthHandler
import java.sql.Timestamp

open class BaseReqHeaderModel {
    var headers = HashMap<String, String>()
    init {
        headers["businessId"] = "MobileNativeRebuild " + getTimeStamp()
        headers["originApplication"] = "MOB"
        headers["X-Forwarded-For"] = "12.13.14.15"
        headers["referer"] = "https://cbihsl01.digitalgrf:10606/CB/p"
        headers["browserUrl"] = "https://example.com/page?q=123"
        headers["remoteAddress"] = "12.13.14.15"
        headers["authenticationToken"]
        headers["Authorization"] = AuthHandler.defaultHandler().authorization
        headers["Cache-Control"] = "no-store"

        if (NetworkManager.coopCookieManager.cookieStore.cookies.size > 0) {
            headers["Cookie"] = TextUtils.join(";", NetworkManager.coopCookieManager.cookieStore.cookies)
        }
    }
    private fun getTimeStamp(): String {
        return Timestamp(System.currentTimeMillis()).toString()
    }
}
