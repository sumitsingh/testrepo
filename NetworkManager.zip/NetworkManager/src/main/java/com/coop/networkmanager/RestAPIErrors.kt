/*
 * Created by the co-operative bank.
 * Copyright (c) 2020 . All rights reserved.
 * Last modified 4/15/20 6:40 PM
 */

package com.coop.networkmanager

import com.coop.coopcore.utils.*

enum class RestAPIErrors(val coopError: CoopError) {
    SocketTimeoutExcepton(CoopError("SocketTimeout", SocketTimeoutException("SocketTimeout error"))),
    NoNetworkException(CoopError("No network", null)),
    NoDataException(CoopError("No data", null)),
    KonyError(CoopError("Kony error", null)),
    ForbiddenError(CoopError("Access forbidden", ForbiddenError("Forbidden error"))),
    GlobalConnectionError(CoopError("", GlobalError("Global connection error"))),
    GlobalGoBackConnectionError(CoopError("", GlobalGoBackError("Global connection error"))),
    Global503Error(CoopError(ServiceResponseErrorCodes.ERROR_CODE_503.key, GlobalGoBackError("Service temporarily unavailable error"))),
    Global500Error(CoopError(ServiceResponseErrorCodes.ERROR_CODE_500.key, GlobalGoBackError("Internal server error"))),
    GlobalInternetConnectionError(CoopError(ServiceResponseErrorCodes.ERROR_CODE_NO_INTERNET.key, GlobalError("Internet Error"))),
    ;

    fun <T : Any> getErrorForRequest(coopResult: CoopResult<T>): CoopError {
        var errorWithResponseDetails = coopError
        errorWithResponseDetails.requestStatus = coopResult.requestStatus
        return errorWithResponseDetails
    }
}
