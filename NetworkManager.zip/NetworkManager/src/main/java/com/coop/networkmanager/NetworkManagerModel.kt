/*
 * Created by the co-operative bank.
 * Copyright (c) 2020 . All rights reserved.
 * Last modified 4/15/20 6:40 PM
 */

package com.coop.networkmanager

data class NetworkManagerModel(
    var base: String = "",
    var path: String = "",
    var endPoint: String = "",
    var postParams: HashMap<String, Any?> = HashMap(),
    var headers: HashMap<String, String> = HashMap(),
    var method: NetworkManagerMethods = NetworkManagerMethods.POST
)
