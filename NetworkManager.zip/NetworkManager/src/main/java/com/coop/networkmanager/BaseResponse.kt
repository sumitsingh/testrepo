/*
 * Created by the co-operative bank.
 * Copyright (c) 2020 . All rights reserved.
 * Last modified 4/15/20 6:40 PM
 */

package com.coop.networkmanager

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize


open class BaseResponse {
    val opstatus: Int? = null
    val dateTime: DateTime? = null
    // val errors: List<Error>? = null
    val httpStatusCode: Int? = null

    data class DateTime(
        val dateTime: String? = null
    )

    @Parcelize
    data class Error(
        val errorSeverity: String? = null,
        val errorMessage: String? = null,
        val errorID: String? = null,
        val errorParams: String? = null
    ): Parcelable
}
