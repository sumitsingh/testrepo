/*
 * Created by the co-operative bank.
 * Copyright (c) 2020 . All rights reserved.
 * Last modified 4/15/20 6:40 PM
 */

package com.coop.networkmanager

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.IgnoredOnParcel
import kotlinx.android.parcel.Parcelize

class FileResModel : BaseResponse() {
    var fileDetails: CoOpFile? = null
    val errors: List<ServiceResponseErrorModel>? = null
}

@Parcelize
@Suppress("PLUGIN_WARNING")
class ServiceResponseErrorModel : Parcelable {
    @SerializedName("messageId")
    val messageId: String? = null

    @SerializedName("params")
    val params: List<Any>? = null

    @SerializedName("severity")
    val severity: String? = null
}
