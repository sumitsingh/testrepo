/*
 * Created by the co-operative bank.
 * Copyright (c) 2020 . All rights reserved.
 * Last modified 4/15/20 6:40 PM
 */

package com.coop.networkmanager

import com.coop.coopcore.utils.AuthHandler

open class BaseReqModel(var brand: String) {

    var appID: String = "CBApp" // TODO  Coop or Smile
    var channel1: String = "mobile"
    var authenticationToken: String = ""

    var parameters = HashMap<String, Any?>()
    var headers = HashMap<String, String>()

    init {
        parameters["brand"] = this.brand
        parameters["channel1"] = this.channel1
        parameters["appID"] = this.appID
        parameters["deviceID"] = AuthHandler.defaultHandler().deviceID
        parameters["randomToken"] = AuthHandler.defaultHandler().token
        parameters["authenticationToken"] = authenticationToken
    }
}
