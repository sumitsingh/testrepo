/*
 * Created by the co-operative bank.
 * Copyright (c) 2020 . All rights reserved.
 * Last modified 4/15/20 6:40 PM
 */

package com.coop.networkmanager

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
class CoOpFile(
    val Url: String ? = "",
    var localPath: String ? = "",
    var fileName: String? = "",
    val type: String ? = ""
) : Parcelable {
    override fun equals(other: Any?) =
        (other is CoOpFile) &&
            Url == other.Url &&
            fileName == other.fileName &&
            localPath == other.localPath &&
            type == other.type

    fun fullLocalPath(): String = "$localPath/$fileName"
}
