/*
 * Created by the co-operative bank.
 * Copyright (c) 2020 . All rights reserved.
 * Last modified 4/15/20 6:40 PM
 */

package com.coop.networkmanager

import com.coop.coopcore.parsers.CoopParser
import com.coop.coopcore.utils.LogUtils
import java.io.*

class RestApiResponse<T>(
    val data: T? = null,
    val code: Int? = null,
    val message: String? = null,
    val inputStream: InputStream? = null,
    val body: String? = null,
    val headers: Map<String, List<String>>? = null,
    val networkManagerModel: NetworkManagerModel? = null,
) {

    fun isSuccessful(): Boolean {
        if (code != null) {
            return code in 200..10002
        }

        return false
    }

    fun isReturnedCode(): Int? {
        return code
    }

    data class Builder<T>(
        var parseTo: Class<T>? = null,
        var code: Int? = 0,
        var message: String? = "",
        var inputStream: InputStream? = null,
        var headers: Map<String, List<String>> = emptyMap(),
        var networkManagerModel: NetworkManagerModel? = null,
    ) {
        private var streamClosed = false
        fun parseTo(parseTo: Class<T>) = apply { this.parseTo = parseTo }
        fun code(code: Int) = apply { this.code = code }
        fun message(message: String) = apply { this.message = message }
        fun inputStream(inputStream: InputStream?) = apply { this.inputStream = inputStream }
        fun headers(headers: Map<String, List<String>>) = apply { this.headers = headers }
        fun networkManagerModel(networkManagerModel: NetworkManagerModel?) = apply { this.networkManagerModel = networkManagerModel }

        fun build() = RestApiResponse(
            parse(inputStream, parseTo),
            code,
            message,
            inputStream,
            readStream(if (streamClosed) null else BufferedInputStream(inputStream)),
            headers,
            networkManagerModel
        )

        private fun <T> parse(inputStream: InputStream?, classOfT: Class<T>?): T? {
            if (inputStream == null || classOfT == null) {
                streamClosed = true
                return classOfT?.newInstance()
            }
            val string = readStream(BufferedInputStream(inputStream))
            streamClosed = true
            LogUtils.errorLog("Res json", string)
            return CoopParser().parseString(string, classOfT)
        }

        private fun readStream(`in`: InputStream?): String {
            if (`in` == null) {
                return ""
            }

            var reader: BufferedReader? = null
            val displayMessage = StringBuffer()
            try {
                reader = BufferedReader(InputStreamReader(`in`))
                var line: String? = null
                while ({ line = reader.readLine(); line }() != null) {
                    displayMessage.append(line)
                }
            } catch (e: IOException) {
                e.printStackTrace()
            } finally {
                if (reader != null) {
                    try {
                        reader.close()
                    } catch (e: IOException) {
                        e.printStackTrace()
                    }
                }
            }
            return displayMessage.toString()
        }
    }

    @Suppress("UNCHECKED_CAST")
    data class FileBuilder<T>(
        var code: Int? = 0,
        var message: String? = "",
        var headers: Map<String, List<String>> = emptyMap(),
        var url: String? = "",
        var localPath: String,
        var localFilename: String
    ) {

        fun code(code: Int) = apply { this.code = code }
        fun message(message: String) = apply { this.message = message }
        fun headers(headers: Map<String, List<String>>) = apply { this.headers = headers }

        var response: FileResModel = FileResModel()

        init {
            response.fileDetails = CoOpFile(url, localPath, localFilename)
        }

        fun build() = RestApiResponse(
            response as T,
            code,
            message,
            headers = headers
        )
    }
}
