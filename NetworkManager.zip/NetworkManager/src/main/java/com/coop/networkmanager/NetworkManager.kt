/*
 * Created by the co-operative bank.
 * Copyright (c) 2020 . All rights reserved.
 * Last modified 4/15/20 6:40 PM
 */

package com.coop.networkmanager

import com.coop.coopcore.authutil.SecurityUtils
import com.coop.coopcore.presentables.NetworkPresentable
import com.coop.coopcore.utils.AppConfiguration
import com.coop.coopcore.utils.AuthHandler
import com.coop.coopcore.utils.LogUtils
import com.coop.coopcore.utils.ServiceFailureLogs
import com.google.gson.Gson
import java.io.BufferedWriter
import java.io.OutputStreamWriter
import java.io.Writer
import java.net.*
import java.util.*

class NetworkManager<T>(val networkModel: NetworkManagerModel) : NetworkPresentable {

    val COOKIES_HEADER = "Set-Cookie"

    companion object {
        const val READ_TIMEOUT = 15000
        const val CONNECTION_TIMEOUT = 15000
        const val COP_READ_TIMEOUT = 3500
        const val COP_CONNECTION_TIMEOUT = 3500

        val coopCookieManager = CookieManager()
    }

    fun execute(classOfType: Class<T>): RestApiResponse<T> {
        if (isNetworkAvailable(AppConfiguration.defaultConfig().context)) {
            try {
                val url = URL((networkModel.base + networkModel.path + networkModel.endPoint))
                val connection = url.openConnection() as HttpURLConnection
                LogUtils.errorLog(SecurityUtils.TAG, "URL: $url")
                networkModel.headers["Content-Type"] = "application/json"
                networkModel.headers["Accept"] = "application/json"

                if (networkModel.headers.size > 0) {
                    for (header in networkModel.headers) {
                        connection.setRequestProperty(header.key, header.value)
                    }
                }

                connection.readTimeout = READ_TIMEOUT
                connection.connectTimeout = CONNECTION_TIMEOUT

                if (networkModel.endPoint.contains("checkCoP")) {
                    connection.readTimeout = COP_READ_TIMEOUT
                    connection.connectTimeout = COP_CONNECTION_TIMEOUT
                }

                connection.doInput = true
                connection.doOutput = true
                connection.setRequestProperty("User-Agent", "URLConnection/" + AuthHandler.defaultHandler().devicename + "/" + AuthHandler.defaultHandler().userAgent)

                when (networkModel.method) {
                    NetworkManagerMethods.GET -> connection.requestMethod = "GET"
                    NetworkManagerMethods.POST, NetworkManagerMethods.PUT -> {
                        val postData = getPOSTDataString(networkModel.postParams)
                        LogUtils.errorLog(SecurityUtils.TAG, "Params: " + postData)
                        connection.requestMethod = networkModel.method.toString()
                        connection.setFixedLengthStreamingMode(postData.toByteArray().size)
                        connection.doInput = true
                        connection.doOutput = true
                        val outputStream = connection.outputStream
                        val bufferedWriter = BufferedWriter(OutputStreamWriter(outputStream, "UTF-8") as Writer)
                        bufferedWriter.write(postData)
                        bufferedWriter.flush()
                        bufferedWriter.close()
                        outputStream.close()
                    }
                    else ->
                        print("TODO unsupported networkModel.method")
                }

                if (BuildConfig.DEBUG) {
                    val builder = StringBuilder()
                    builder.append(connection.responseCode)
                        .append(" ")
                        .append(networkModel.method.name)
                        .append(" ")
                        .append(connection.responseMessage)
                        .append("\n")

                    val map = connection.headerFields
                    for (entry in map.entries) {
                        if (entry.key == null)
                            continue
                        builder.append(entry.key)
                            .append(": ")

                        val headerValues = entry.value
                        LogUtils.errorLog(SecurityUtils.TAG, "headerValues: $headerValues")
                        val it = headerValues.iterator()
                        if (it.hasNext()) {
                            builder.append(it.next())

                            while (it.hasNext()) {
                                builder.append(", ")
                                    .append(it.next())
                            }
                        }

                        builder.append("\n")
                    }
                    LogUtils.errorLog(SecurityUtils.TAG, "res log $builder")
                }

                if (connection.errorStream != null) {
                    if (BuildConfig.DEBUG)createErrorLogData(connection)
                    return RestApiResponse.Builder<T>()
                        .parseTo(classOfType)
                        .code(connection.responseCode)
                        .inputStream(connection.errorStream)
                        .headers(connection.headerFields)
                        .message(connection.responseMessage)
                        .networkManagerModel(networkManagerModel = networkModel)
                        .build()
                } else {
                    LogUtils.errorLog(SecurityUtils.TAG, "Response " + connection.responseMessage)
                    val headerFields = connection.headerFields
                    val cookiesHeader = headerFields[COOKIES_HEADER]

                    if (cookiesHeader != null) {
                        for (cookie in cookiesHeader) {
                            coopCookieManager.cookieStore.add(null, HttpCookie.parse(cookie)[0])
                        }
                    }
                    return RestApiResponse.Builder<T>()
                        .parseTo(classOfType)
                        .code(connection.responseCode)
                        .inputStream(connection.inputStream)
                        .headers(connection.headerFields)
                        .message(connection.responseMessage)
                        .networkManagerModel(networkManagerModel = networkModel)
                        .build()
                }
            } catch (e: SocketTimeoutException) {
                if (BuildConfig.DEBUG) {
                    e.printStackTrace()
                }
                return RestApiResponse.Builder<T>()
                    .message(e.cause?.localizedMessage ?: "")
                    .networkManagerModel(networkManagerModel = networkModel)
                    .build()
            } catch (e: Exception) {
                if (BuildConfig.DEBUG) {
                    e.printStackTrace()
                }
                return RestApiResponse.Builder<T>()
                    .message(e.cause?.localizedMessage ?: "")
                    .networkManagerModel(networkManagerModel = networkModel)
                    .build()
            }
        } else {
            return RestApiResponse.Builder<T>()
                .code(ServiceResponseErrorCodes.ERROR_CODE_NO_INTERNET.key.toInt())
                .message("No Internet check ")
                .networkManagerModel(networkManagerModel = networkModel)
                .build()
        }
    }

    private fun createErrorLogData(connection: HttpURLConnection) {
        val errorReport = java.lang.StringBuilder()
        errorReport.append("\nLog Time: " + System.currentTimeMillis())
        errorReport.append("\nApp package Name : " + AppConfiguration.defaultConfig().context.packageName)
        errorReport.append("\nDCID: " + AuthHandler.defaultHandler().dcIdNumber)
        errorReport.append("\nREQUEST LOG")
        errorReport.append("\nAPI end Point  =  " + networkModel.base + networkModel.path + networkModel.endPoint)
        errorReport.append("\nHTTP Method  =  " + networkModel.method.name)
        errorReport.append("\nRequest Header = " + networkModel.headers)
        if (networkModel.method == NetworkManagerMethods.POST || networkModel.method == NetworkManagerMethods.PUT) {
            val postData = getPOSTDataString(networkModel.postParams)
            errorReport.append("\nRequest Body = $postData")
        }
        errorReport.append("\n\nRESPONSE LOG")
        errorReport.append("\nResponse code :" + connection.responseCode)
        errorReport.append("\nResponse :" + connection.responseMessage)
        ServiceFailureLogs().writeData(AppConfiguration.defaultConfig().context, errorReport.toString())
    }

    fun getPOSTDataString(hashMap: HashMap<String, Any?>, parser: Gson = Gson()): String {
        return parser.toJson(hashMap)
    }
}
