/*
 * Created by the co-operative bank.
 * Copyright (c) 2020 . All rights reserved.
 * Last modified 4/15/20 6:40 PM
 */

package com.coop.networkmanager

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.coop.coopcore.model.RequestAndStatusModel
import com.coop.coopcore.utils.CoopError
import com.coop.coopcore.utils.CoopResult
import com.coop.coopcore.utils.CoopResultStatus
import java.io.IOException

open class BaseRepository {

    // Properties
    val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading

    // Errors
    val displayError = MutableLiveData<CoopError>()

    suspend fun <T : Any> safeApiCall(call: suspend() -> RestApiResponse<T>, errorMessage: String): CoopResult<T> {
        return safeApiResult(call, errorMessage)
    }

    private suspend fun <T : Any> safeApiResult(call: suspend() -> RestApiResponse<T>, errorMessage: String): CoopResult<T> {
        val response = call.invoke()
        if (response.isSuccessful()) {
            return if (response.data != null) {
                when (response.code) {
                    200 -> {
                        CoopResult.success(response.data, requestStatus = RequestAndStatusModel(endpoint = response.networkManagerModel?.endPoint, httpMethod = response.networkManagerModel?.method?.name, responseCode = response.code))
                    }
                    206 -> {
                        CoopResult.success(response.data, requestStatus = RequestAndStatusModel(endpoint = response.networkManagerModel?.endPoint, httpMethod = response.networkManagerModel?.method?.name, responseCode = response.code))
                    }
                    503, 401 -> {
                        CoopResult.error(RestAPIErrors.Global503Error.coopError, null, requestStatus = RequestAndStatusModel(endpoint = response.networkManagerModel?.endPoint, httpMethod = response.networkManagerModel?.method?.name, responseCode = response.code))
                    }
                    500 -> {
                        CoopResult.error(RestAPIErrors.Global500Error.coopError, null, requestStatus = RequestAndStatusModel(endpoint = response.networkManagerModel?.endPoint, httpMethod = response.networkManagerModel?.method?.name, responseCode = response.code))
                    }
                    else -> {
                        CoopResult.error(RestAPIErrors.Global500Error.coopError, null, requestStatus = RequestAndStatusModel(endpoint = response.networkManagerModel?.endPoint, httpMethod = response.networkManagerModel?.method?.name))
                    }
                }
            } else {
                when (response.code) {
                    10002 -> {
                        CoopResult.error(RestAPIErrors.GlobalInternetConnectionError.coopError, response.data, requestStatus = RequestAndStatusModel(endpoint = response.networkManagerModel?.endPoint, httpMethod = response.networkManagerModel?.method?.name))
                    }
                    else -> {
                        CoopResult.error(RestAPIErrors.NoDataException.coopError, null, requestStatus = RequestAndStatusModel(endpoint = response.networkManagerModel?.endPoint, httpMethod = response.networkManagerModel?.method?.name))
                    }
                }
            }
        } else if (response.data != null || response.isReturnedCode() != 0) {
            return CoopResult.error(RestAPIErrors.ForbiddenError.coopError, response.data, requestStatus = RequestAndStatusModel(endpoint = response.networkManagerModel?.endPoint, httpMethod = response.networkManagerModel?.method?.name))
        } else if (response.message?.contains("Socket closed")!! || response.message.contains("Read timed out")) {
            return CoopResult.error(RestAPIErrors.SocketTimeoutExcepton.coopError, null, requestStatus = RequestAndStatusModel(endpoint = response.networkManagerModel?.endPoint, httpMethod = response.networkManagerModel?.method?.name))
        }

        // TODO handle errors properly
        return CoopResult.error(IOException("Error Occurred during getting safe Api result, Custom ERROR " + "- $errorMessage"), null, requestStatus = RequestAndStatusModel(endpoint = response.networkManagerModel?.endPoint, httpMethod = response.networkManagerModel?.method?.name))
    }

    open suspend fun <T : Any> handleResult(newData: CoopResult<T>) {
        if (newData.status == CoopResultStatus.ERROR) {
            when (newData.error?.message) {
                ServiceResponseErrorCodes.ERROR_CODE_503.key -> {
                    displayError.postValue(RestAPIErrors.Global503Error.getErrorForRequest(newData))
                }
                ServiceResponseErrorCodes.ERROR_CODE_500.key -> {
                    displayError.postValue(RestAPIErrors.Global500Error.getErrorForRequest(newData))
                }
                ServiceResponseErrorCodes.ERROR_CODE_NO_INTERNET.key -> {
                    displayError.postValue(RestAPIErrors.GlobalInternetConnectionError.getErrorForRequest(newData))
                }
                else -> {
                    displayError.postValue(RestAPIErrors.GlobalGoBackConnectionError.getErrorForRequest(newData))
                }
            }
        }
    }

    /**
     * Used for testing only to override the response with an error response
     */
    suspend fun <T : Any> testSafeApiCall(call: suspend() -> RestApiResponse<T>, errorMessage: String): CoopResult<T> {
        return testSafeApiResult(call, errorMessage, 500)
    }

    /**
     * Used for testing only to override the response with an error response
     */
    private suspend fun <T : Any> testSafeApiResult(call: suspend() -> RestApiResponse<T>, errorMessage: String, errorCode: Int): CoopResult<T> {
        val response = call.invoke()
        val endpoint = response.networkManagerModel?.endPoint
        val method = response.networkManagerModel?.method?.name
        val coopError = when (errorCode) {
            503, 401 -> RestAPIErrors.Global503Error.coopError
            10002 -> RestAPIErrors.GlobalInternetConnectionError.coopError
            else -> RestAPIErrors.Global500Error.coopError
        }
        return CoopResult.error(coopError, null, requestStatus = RequestAndStatusModel(endpoint = endpoint, httpMethod = method, responseCode = errorCode))
    }
}

