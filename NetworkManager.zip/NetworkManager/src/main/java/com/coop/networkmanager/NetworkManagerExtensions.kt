/*
 * Created by the co-operative bank.
 * Copyright (c) 2020 . All rights reserved.
 * Last modified 4/15/20 6:40 PM
 */

package com.coop.networkmanager

import com.coop.coopcore.utils.AppConfiguration
import com.coop.coopcore.utils.LogUtils
import java.io.*
import java.net.HttpURLConnection
import java.net.URL

fun File.copyInputStreamToFile(inputStream: InputStream) {
    this.outputStream().use { fileOut ->
        inputStream.copyTo(fileOut)
    }
}

fun <T> NetworkManager<T>.execute(localPath: String, localFilename: String, internal: Boolean = true): RestApiResponse<T> {
    if (isNetworkAvailable(AppConfiguration.defaultConfig().context)) {
        try {
            val url = URL((networkModel.base + networkModel.path + networkModel.endPoint))
            val connection = url.openConnection() as HttpURLConnection
            val outFileUrl: String

            if (internal) {
                networkModel.headers["Content-Type"] = "application/json"
                networkModel.headers["Accept"] = "application/pdf"

                if (networkModel.headers.size > 0) {
                    for (header in networkModel.headers) {
                        connection.setRequestProperty(header.key, header.value)
                    }
                }
                connection.readTimeout = NetworkManager.READ_TIMEOUT
                connection.connectTimeout = NetworkManager.CONNECTION_TIMEOUT
            }

            connection.doInput = true

            when (networkModel.method) {
                NetworkManagerMethods.GET -> connection.requestMethod = "GET"
                NetworkManagerMethods.POST -> {
                    val postData = getPOSTDataString(networkModel.postParams)
                    connection.requestMethod = "POST"
                    connection.setFixedLengthStreamingMode(postData.toByteArray().size)
                    connection.doOutput = true
                    val outputStream = connection.outputStream
                    val bufferedWriter =
                        BufferedWriter(OutputStreamWriter(outputStream, "UTF-8") as Writer)
                    bufferedWriter.write(postData)
                    bufferedWriter.flush()
                    bufferedWriter.close()
                    outputStream.close()
                }
                else ->
                    print("TODO unsupported networkModel.method")
            }

            // opens input stream from the HTTP connection
            val inputStream = connection.inputStream
            val filePath = localPath + File.separator
            outFileUrl = filePath + localFilename

            // Create dirs
            val dirCheck = File(filePath)
            if (!dirCheck.exists()) {
                dirCheck.mkdirs()
            }

            // Delete file if already exists
            val fileCheck = File(outFileUrl)
            if (fileCheck.exists()) {
                fileCheck.delete()
            }

            // Create file
            fileCheck.createNewFile()

            // Copy input stream to file
            fileCheck.copyInputStreamToFile(inputStream)

            // Close stream
            inputStream.close()

            println("File downloaded")

            connection.disconnect()

            if (connection.inputStream == null) {
                throw java.lang.Exception("input stream is null")
            } else {
                LogUtils.infoLog("Response", connection.responseMessage)
                return RestApiResponse.FileBuilder<T>(
                    url = url.toString(),
                    localPath = localPath,
                    localFilename = localFilename
                )
                    .code(connection.responseCode)
                    .headers(connection.headerFields)
                    .message(connection.responseMessage)
                    .build()
            }
        } catch (e: Exception) {
            if (BuildConfig.DEBUG) {
                e.printStackTrace()
            }

            return RestApiResponse.Builder<T>()
                .message(e.cause?.localizedMessage ?: "")
                .networkManagerModel(networkManagerModel = networkModel)
                .build()
        }
    } else {
        return RestApiResponse.Builder<T>()
            .code(ServiceResponseErrorCodes.ERROR_CODE_NO_INTERNET.key.toInt())
            .message("No Internet check ")
            .networkManagerModel(networkManagerModel = networkModel)
            .build()
    }
}
