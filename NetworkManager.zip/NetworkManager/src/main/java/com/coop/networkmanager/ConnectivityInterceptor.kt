// package khalid.com.forecastAppmvvm2.data.response.network
//
// import android.content.Context
// import android.net.ConnectivityManager
//
// class ConnectivityInterceptor(context: Context) {
//    private  val appcontext = context.applicationContext
//
//    private fun isOnline(): Boolean {
//        val connectivityManager = appcontext.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
//        val networkInfo = connectivityManager.activeNetworkInfo
//        return networkInfo !=null && networkInfo.isConnected
//    }
// }
