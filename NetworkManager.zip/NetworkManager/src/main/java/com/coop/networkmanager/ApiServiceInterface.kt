/*
 * Created by the co-operative bank.
 * Copyright (c) 2020 . All rights reserved.
 * Last modified 4/15/20 6:40 PM
 */

package com.coop.networkmanager

interface ApiServiceInterface {

    fun <T> execute(
        parseTo: Class<T>,
        baseUrl: String,
        path: String?,
        endPoint: String?,
        methodType: NetworkManagerMethods = NetworkManagerMethods.GET,
        params: HashMap<String, Any?> = HashMap(),
        headers: HashMap<String, String> = HashMap()
    ): RestApiResponse<T> {

        val model = NetworkManagerModel(baseUrl, path ?: "", endPoint ?: "", params, headers, methodType)

        return NetworkManager<T>(model).execute(parseTo)
    }

    fun <T> execute(
        parseTo: Class<T>,
        baseUrl: String,
        path: String?,
        endPoint: String?,
        localPath: String,
        fileName: String,
        internal: Boolean = true,
        methodType: NetworkManagerMethods = NetworkManagerMethods.GET,
        params: HashMap<String, Any?> = HashMap(),
        headers: HashMap<String, String> = HashMap()
    ): RestApiResponse<T> {

        val model = NetworkManagerModel(baseUrl, path ?: "", endPoint ?: "", params, headers, methodType)

        return NetworkManager<T>(model).execute(localPath, fileName, internal)
    }
}
