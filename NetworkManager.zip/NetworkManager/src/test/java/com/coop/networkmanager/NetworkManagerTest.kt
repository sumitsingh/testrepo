/*
 * Created by the co-operative bank.
 * Copyright (c) 2020 . All rights reserved.
 * Last modified 4/15/20 6:40 PM
 */

package com.coop.networkmanager

import android.content.Context
import android.os.Build
import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import androidx.test.core.app.ApplicationProvider
import com.coop.coopcore.utils.AppConfiguration
import kotlinx.coroutines.runBlocking
import org.junit.*
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@Config(sdk = [Build.VERSION_CODES.P])
@RunWith(RobolectricTestRunner::class)
class NetworkManagerTest {

    private val context = ApplicationProvider.getApplicationContext<Context>()
    private val testUrl = "https://postman-echo.com/"

    @Rule
    @JvmField
    var instantTaskExecutorRule = InstantTaskExecutorRule()

    private lateinit var testApiService: TestApiService

    @Before
    fun setUp() {
        AppConfiguration.defaultConfig().context = context
        testApiService = TestApiService()
    }

    @Test
    fun api_getTestData_shouldSucceed() = runBlocking {
        val response = testApiService.getTestData(testUrl)

        Assert.assertTrue(response.isSuccessful())
    }

    @Test
    fun api_postTestData_shouldSucceed() = runBlocking {
        val response = testApiService.postTestData(testUrl)

        Assert.assertTrue(response.isSuccessful())
    }

    @After
    fun tearDown() {
    }
}

class TestApiService : ApiServiceInterface {
    fun getTestData(url: String) = execute(TestResModel::class.java, url, null, "get?keyOne=valueOne&keyTwo=valueTwo", NetworkManagerMethods.GET)
    fun postTestData(url: String) = execute(TestResModel::class.java, url, null, "post?keyOne=valueOne&keyTwo=valueTwo", NetworkManagerMethods.POST)
}

class TestResModel : BaseResponse() {
    val testKeyOne: String? = null
    val testKeyTwo: String? = null
}
