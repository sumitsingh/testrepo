//
//  APIClient.swift
//  FlickrKit
//
//  Created by Andy Rennard on 14/06/2019.
//  Copyright © 2019 Andy Rennard. All rights reserved.
//

import Foundation

public protocol APIClient {
    var session: URLSession { get }
}

public extension APIClient {

	func perform(request: URLRequest, completion: @escaping (Result<Data, APIError>) -> Void) {
        let task = session.dataTask(with: request) { data, response, error in

            if let error = error {
                completion(.failure(.networkingError(error)))
                return
            }

            guard let http = response as? HTTPURLResponse, let data = data else {
                return completion(.failure(.invalidResponse))
            }

			self.handleStatusCode(http, data, completion: completion)
        }
        task.resume()
    }

	fileprivate func handleStatusCode(_ http: HTTPURLResponse, _ data: Data, completion: @escaping (Result<Data, APIError>) -> Void) {
		switch http.statusCode {
		case 206:
			completion(.failure(.invalidResponse))
		case 200...299:
			completion(.success(data))
		case 400...499:
			let body = String(data: data, encoding: .utf8)
			completion(.failure(.requestError(http.statusCode, body ?? "<no body>")))
		case 500...599:
			completion(.failure(.serverError))
		default:
			completion(.failure(.invalidResponse))
		}
	}

}

// MARK: APIClient - Parser

extension APIClient {
    private var dateFormatter: DateFormatter {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSSZ"
        return formatter
    }

    var defaultJsonDecoder: JSONDecoder {
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .formatted(dateFormatter)
        return decoder
    }

    public var jsonEncoder: JSONEncoder {
        let encoder = JSONEncoder()
        encoder.dateEncodingStrategy = .formatted(dateFormatter)
        return encoder
    }

    public func parseDecodable<T: Decodable>(result: (Result<Data, APIError>),
                                             jsonDecoder: JSONDecoder? = nil,
                                             completion: @escaping (Result<T, APIError>) -> Void) {
        switch result {
        case .success(let data):
            do {
                let customDecoder = jsonDecoder ?? defaultJsonDecoder

                let object = try customDecoder.decode(T.self, from: data)
                DispatchQueue.main.async {
                    completion(.success(object))
                }
            } catch let decodingError as DecodingError {
                // Could be an APIResponse
                if let response = try? JSONDecoder().decode(APIResponse.self, from: data) {
                    DispatchQueue.main.async {
                        completion(.failure(.errorResponse(response)))
                    }
                } else {
                    DispatchQueue.main.async {
                        print("Decoding error: \(decodingError)")
                        completion(.failure(.decodingError(decodingError)))
                    }
                }
            } catch {
                fatalError("Unhandled error raised.")
            }

        case .failure(let error):
            DispatchQueue.main.async {
                completion(.failure(error))
            }
        }
    }
}
