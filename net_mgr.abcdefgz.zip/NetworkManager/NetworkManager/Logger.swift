struct Logger {
    static func logRequest(urlRequest: URLRequest) {
        #if DEBUG
        printRequest(urlRequest: urlRequest)
        #endif
    }

    static func logResponse(data: Data?, response: URLResponse?, error: Error?) {
        #if DEBUG
        printResponse(data: data, response: response, error: error)
        #endif
    }

    private static func printRequest(urlRequest: URLRequest) {
        print("\n------------------------------------------Start Request---------------------------------------------------")
        print(urlRequest)
        print("httpMethod -> \(urlRequest.httpMethod ?? "")")
        if let allHTTPHeaderFields = urlRequest.allHTTPHeaderFields {
            print("allHTTPHeaderFields -> \(allHTTPHeaderFields)")
        }
        if let httpBody = urlRequest.httpBody {
            print("httpBody -> \(stringRepresentation(of: httpBody))")
        }
        print("------------------------------------------End Request-----------------------------------------------------\n")
    }

    private static func printResponse(data: Data?, response: URLResponse?, error: Error?) {
        print("\n------------------------------------------Start Response---------------------------------------------------")
        if let response = response {
            print(response)
        }
        if let data = data {
            print("Data -> \(stringRepresentation(of: data))")
        }
        if let error = error {
            print("Error -> \(error)")
        }
        print("------------------------------------------End Response-----------------------------------------------------\n")
    }

    private static func stringRepresentation(of data: Data) -> NSString {
        NSString(data: data, encoding: String.Encoding.utf8.rawValue) ?? ""
    }

    public static func writeDebugLogToFile(request: URLRequest, data: Data?, response: URLResponse?, error: Error?) {
        #if DEBUG
            writeLogToFile(request: request, data: data, response: response, error: error)
        #endif
    }

    // swiftlint:disable:next function_body_length
    private static func writeLogToFile(request: URLRequest, data: Data?, response: URLResponse?, error: Error?) {
        let appName = Bundle.main.infoDictionary?[kCFBundleNameKey as String] as? String
        let logFileName = "\(appName ?? "Coop")_debug_logs.txt"

        let path = URL(fileURLWithPath: NSTemporaryDirectory()).appendingPathComponent(logFileName)
        print("path: \(path)")
        var log = "\n---------------------------------------------Log Start-------------------------------------------------\n"
        log.append("\nLog Time: \(Date().timeIntervalSince1970)")
        log.append("\nApp Bundle Id: \(String(describing: Bundle.main.bundleIdentifier ?? ""))")
        if let dcid = UserDefaults.standard.value(forKey: "debug_mode_DCID") {
            log.append("DCID: \(dcid)")
        }

        log.append("\n\nREQUEST LOG")
        log.append("\nAPI End Point = \(request.url?.absoluteString ?? "")")
        log.append("\nHTTP Method = \(request.httpMethod ?? "")")
        log.append("\nRequest Header = \(request.allHTTPHeaderFields?.description ?? "")")
        if let bodyData = request.httpBody {
            log.append("\n\nRequest Body = \(stringRepresentation(of: bodyData))")
        }

        log.append("\n\nRESPONSE LOG")

        if let response = response {
            log.append("\n\(response)")
        }
        if let data = data {
            log.append("\nReponse result: \(stringRepresentation(of: data))")
        }
        if let error = error {
            log.append("\nService Error: \(error)")
        }

        log += "\n---------------------------------------------End of Log-------------------------------------------------\n\n\n"

        if !FileManager.default.fileExists(atPath: path.path) {
            FileManager.default.createFile(atPath: path.path, contents: nil)
        }

        if let data = log.data(using: .utf8) {
            do {
                let fileHandle = try FileHandle(forWritingTo: path)
                fileHandle.seekToEndOfFile()
                fileHandle.write(data)
                fileHandle.closeFile()
            } catch {
                print("Can't write logs in file")
            }
        } else {
            try? log.data(using: .utf8)?.write(to: path)
        }
    }
}
