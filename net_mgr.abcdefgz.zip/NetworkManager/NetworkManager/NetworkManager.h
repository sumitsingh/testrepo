//
//  NetworkManager.h
//  NetworkManager
//
//  Created by Alex Franco on 12/02/2020.
//  Copyright © 2020 Alex Franco. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for NetworkManager.
FOUNDATION_EXPORT double NetworkManagerVersionNumber;

//! Project version string for NetworkManager.
FOUNDATION_EXPORT const unsigned char NetworkManagerVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <NetworkManager/PublicHeader.h>


