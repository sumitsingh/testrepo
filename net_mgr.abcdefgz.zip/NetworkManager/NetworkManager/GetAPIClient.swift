//
//  GetAPIClient.swift
//  NetworkManager
//
//  Created by Mayur on 18/02/2020.
//  Copyright © 2020 Alex Franco. All rights reserved.
//

import Foundation
public class GetAPIClient: APIClient {
    public var session: URLSession

    public init(session: URLSession = NetworkManager.pinnedSession()) {
           self.session = session
           session.configuration.httpCookieAcceptPolicy = .always
       }

    public func performFor(request: inout URLRequest, completion: @escaping (Result<Data?, APIError>) -> Void) {
        request.httpMethod = HTTPMethod.GET.rawValue

        perform(request: request) { (result) in
            switch result {
            case .success(let data):
				DispatchQueue.main.async {
					completion(.success(data))
				}
            case .failure(let error):
                DispatchQueue.main.async {
                    completion(.failure(error))
                }
            }
        }
    }

    public func perform<U: Codable>(request: inout URLRequest,
                                    with requestModel: U,
                                    completion: @escaping (Result<Data, APIError>) -> Void) {

        let requestBody: Data!
        do {
            try requestBody = jsonEncoder.encode(requestModel)
        } catch let error {
            completion(.failure(APIError.encodingError(error)))
            return
        }
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = requestBody
        perform(request: request) { (result) in
            switch result {
            case .success(let data):
                    DispatchQueue.main.async {
                        completion(.success(data))
                    }

            case .failure(let error):
                DispatchQueue.main.async {
                    completion(.failure(error))
                }
            }
        }
    }

}
