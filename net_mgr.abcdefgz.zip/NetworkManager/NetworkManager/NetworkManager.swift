//
//  NetworkManager.swift
//  NetworkManager
//
//  Copyright © 2021 The Co-operative Bank. All rights reserved.
//

import Foundation
import TrustKit

public class NetworkManager {
    private static let certPinHandler = CertificatePinHandler()
    private static var certPinningEnabled = false

    public static func initialise(domain: String, certificates: [String], certPinningEnabled: Bool) {
        NetworkManager.certPinningEnabled = certPinningEnabled
        let trustKitConfig = [
                    kTSKSwizzleNetworkDelegates: false,
                    kTSKPinnedDomains: [
                        domain: [
                            kTSKEnforcePinning: true,
                            kTSKIncludeSubdomains: true,
                            kTSKPublicKeyHashes: certificates
                        ]
                    ]
        ] as [String: Any]

        if certPinningEnabled {
            TrustKit.initSharedInstance(withConfiguration: trustKitConfig)
        }
    }

    public static func pinnedSession() -> URLSession {
        return URLSession(configuration: URLSessionConfiguration.default, delegate: certPinHandler, delegateQueue: nil)
    }

    private class CertificatePinHandler: NSObject, URLSessionDelegate {

        func urlSession(_ session: URLSession,
                        didReceive challenge: URLAuthenticationChallenge,
                        completionHandler: @escaping (URLSession.AuthChallengeDisposition, URLCredential?) -> Void) {

            if certPinningEnabled {
                if !TrustKit.sharedInstance().pinningValidator.handle(challenge, completionHandler: completionHandler) {
                    completionHandler(.performDefaultHandling, nil)
                }
            } else {
                completionHandler(.performDefaultHandling, nil)
            }
        }
    }
}
