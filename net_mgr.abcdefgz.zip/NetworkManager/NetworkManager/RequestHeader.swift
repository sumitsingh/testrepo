import Foundation
import UIKit

public typealias RequestHeaderType = (key: String, value: String)

public final class RequestHeader {
    public static let acceptApplicationJson = RequestHeaderType("Accept", "application/json")
    public static let acceptApplicationPdf = RequestHeaderType("Accept", "application/pdf")
    public static let contentTypeApplicationJson = RequestHeaderType("Content-Type", "application/json")
    public static let originApplication = RequestHeaderType("originApplication", "MOB")
    public static let cacheControl = RequestHeaderType("Cache-Control", "no-store")

    public static func clientId(_ id: String) -> RequestHeaderType {
        return RequestHeaderType("client_id", id)
    }

    public static func clientSecret(_ secret: String) -> RequestHeaderType {
        return RequestHeaderType("client_secret", secret)
    }

    public static func authenticationToken(_ authToken: String) -> RequestHeaderType {
        return RequestHeaderType("authenticationToken", authToken)
    }

    public static func authorization(_ authToken: String) -> RequestHeaderType {
        return RequestHeaderType("Authorization", authToken)
    }

    public static func jwtToken(_ authToken: String) -> RequestHeaderType {
        return RequestHeaderType("jwtToken", authToken)
    }

    public static func businessId() -> RequestHeaderType {
        let strMobileNativeRebuild = "MobileNativeRebuild"
        let now = Date()
        let formatter = DateFormatter()
        formatter.timeZone = TimeZone.current
        formatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        let dateString = formatter.string(from: now)
        let finalString = strMobileNativeRebuild + dateString
        return RequestHeaderType("businessId", finalString)
    }

    public static func xForwardedFor(ip: String) -> RequestHeaderType {
        return RequestHeaderType("X-Forwarded-For", ip)
    }

    public static func remoteAddress(ip: String) -> RequestHeaderType {
        return RequestHeaderType("remoteAddress", ip)
    }

    // swiftlint:disable:next function_body_length
    private static func getIPAddress() -> String {
        var address: String?
        var ifaddr: UnsafeMutablePointer<ifaddrs>?
        if getifaddrs(&ifaddr) == 0 {
            var ptr = ifaddr
            while ptr != nil {
                defer { ptr = ptr?.pointee.ifa_next }

                guard let interface = ptr?.pointee else { return "" }
                let addrFamily = interface.ifa_addr.pointee.sa_family
                if addrFamily == UInt8(AF_INET) || addrFamily == UInt8(AF_INET6) {
                    // wifi = ["en0"]
                    // wired = ["en2", "en3", "en4"]
                    // cellular = ["pdp_ip0","pdp_ip1","pdp_ip2","pdp_ip3"]
                    let name: String = String(cString: (interface.ifa_name))
                    let interfaces = [
                        "en0",
                        "en2",
                        "en3",
                        "en4",
                        "pdp_ip0",
                        "pdp_ip1",
                        "pdp_ip2",
                        "pdp_ip3"
                    ]

                    if  interfaces.contains(name) {
                        var hostname = [CChar](repeating: 0, count: Int(NI_MAXHOST))
                        getnameinfo(interface.ifa_addr,
                                    socklen_t((interface.ifa_addr.pointee.sa_len)),
                                    &hostname,
                                    socklen_t(hostname.count),
                                    nil,
                                    socklen_t(0),
                                    NI_NUMERICHOST)
                        address = String(cString: hostname)
                    }
                }
            }
            freeifaddrs(ifaddr)
        }
        return address ?? "No IP Address Found"
    }
}
