//
//  APIResponse.swift
//  CoopRest
//
//  Created by Andy Rennard on 06/08/2019.
//  Copyright © 2019 Coop. All rights reserved.
//

import Foundation

/// A type that models the response from an API request
public struct APIResponse: Codable {

    let status: Int
    let httpStatusCode: Int
    let randomToken: UUID

    enum CodingKeys: String, CodingKey {
        case status = "opstatus"
        case httpStatusCode = "httpStatusCode"
        case randomToken = "mfaRandomTknAppLevel"
    }

    public init(status: Int = 200, httpStatusCode: Int = 200, message: String = "", randomToken: UUID = UUID()) {
        self.status = status
        self.httpStatusCode = httpStatusCode
        self.randomToken = randomToken
    }
}
