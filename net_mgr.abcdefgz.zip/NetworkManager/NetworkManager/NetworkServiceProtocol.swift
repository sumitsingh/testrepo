public protocol NetworkServiceProtocol {
    typealias SuccessResult<T> = (data: T, httpUrlResponse: HTTPURLResponse)
    typealias Completion = (Result<(data: Data?, httpUrlResponse: HTTPURLResponse), NetworkServiceError>) -> Void
    typealias DecodableCompletion<T> = (Result<SuccessResult<T>, NetworkServiceError>) -> Void

    func makeRequest(networkRequest: NetworkRequestProtocol, completeOnMainThread: Bool, completion: @escaping Completion)
    func makeRequest<T: Decodable>(networkRequest: NetworkRequestProtocol,
                                   type: T.Type,
                                   completeOnMainThread: Bool,
                                   completion: @escaping DecodableCompletion<T>)
}
