import Foundation

extension Int {
    public func isHttpSuccessStatusCode() -> Bool {
        return (200...299).contains(self)
    }
}
