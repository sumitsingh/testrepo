//
//  Codable+Extensions.swift
//  CoopCore
//
//  Created by Andy Rennard on 27/09/2019.
//  Copyright © 2019 Andy Rennard. All rights reserved.
//

import Foundation

public extension Encodable {
    var JSONRepresenatation: String? {
        let encoder = JSONEncoder.standard
        do {
            let jsonData = try encoder.encode(self)
            return String(data: jsonData, encoding: .utf8)
        } catch {
            print("Failed to decode jsonData")
            return nil
        }
    }

	var JSONDataRepresenatation: Data? {
		 let encoder = JSONEncoder.standard
		 do {
			 return try encoder.encode(self)
		 } catch {
			 print("Failed to decode jsonData")
			 return nil
		 }
	 }
}

public extension JSONEncoder {
    static var standard: JSONEncoder {
        let encoder = JSONEncoder()
        encoder.dateEncodingStrategy = .iso8601
        encoder.outputFormatting = .prettyPrinted
        return encoder
    }
}

public extension JSONDecoder {
    static var standard: JSONDecoder {
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        return decoder
    }
}
