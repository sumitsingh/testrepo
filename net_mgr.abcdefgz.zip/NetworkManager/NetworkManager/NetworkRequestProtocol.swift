import Foundation

public protocol NetworkRequestProtocol {
    var url: URL { get }
    var urlPaths: [String] { get }
    var cachePolicy: URLRequest.CachePolicy? { get }
    var httpMethod: HTTPMethod { get }
    var httpHeaders: [RequestHeaderType] { get }
    var httpBody: Data? { get }
    func urlRequest() -> URLRequest
}

extension NetworkRequestProtocol {
    public func urlRequest() -> URLRequest {
        var urlRequest = URLRequest(url: generateUrl())
        urlRequest.httpMethod = httpMethod.rawValue
        urlRequest.httpBody = httpBody
        urlRequest.allHTTPHeaderFields = headersDictionary()
        if let cachePolicy = cachePolicy {
            urlRequest.cachePolicy = cachePolicy
        }
        return urlRequest
    }

    private func headersDictionary() -> [String: String] {
        var dictionary: [String: String] = [:]
        dictionary = HTTPCookie.requestHeaderFields(with: HTTPCookieStorage.shared.cookies!)
        for header in httpHeaders {
            dictionary.updateValue(header.value, forKey: header.key)
        }
        return dictionary
    }

    private func generateUrl() -> URL {
        var urlWithPath = url
        urlPaths.forEach { urlWithPath.appendPathComponent($0) }
        return urlWithPath
    }
}
