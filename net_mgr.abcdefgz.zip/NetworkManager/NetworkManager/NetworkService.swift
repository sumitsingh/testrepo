/**
 This entity is responsible for making network request via URLSession with the option of passing a custom URLSession and JSONDecoder.
 */

public struct NetworkService: NetworkServiceProtocol {
    private let urlSession: URLSession
    private let jsonDecoder: JSONDecoder

    public init (urlSession: URLSession = NetworkManager.pinnedSession(), jsonDecoder: JSONDecoder = Self.standardJsonDecoder) {
        self.urlSession = urlSession
        self.jsonDecoder = jsonDecoder
        urlSession.configuration.httpCookieAcceptPolicy = .always
    }

    public func makeRequest(networkRequest: NetworkRequestProtocol,
                            completeOnMainThread: Bool = true, completion: @escaping Completion) {
        let urlRequest = networkRequest.urlRequest()
        Logger.logRequest(urlRequest: urlRequest)
        let task = urlSession.dataTask(with: urlRequest) { (data, response, error) in
            Logger.logResponse(data: data, response: response, error: error)
            if (response as? HTTPURLResponse)?.statusCode != 200 {
                Logger.writeDebugLogToFile(request: urlRequest, data: data, response: response, error: error)
            }

            if let statusCode = (response as? HTTPURLResponse)?.statusCode,
               !self.isSuccessful(statusCode: statusCode),
               let responseHeaderFields = (response as? HTTPURLResponse)?.allHeaderFields as? [String: String] {
                let cookieArray = HTTPCookie.cookies(withResponseHeaderFields: responseHeaderFields, for: networkRequest.url)
                for cookie in cookieArray {
                    HTTPCookieStorage.shared.setCookie(cookie)
                }
                Self.handleResponse(urlResponse: response, data: data, completeOnMainThread: completeOnMainThread, completion: completion)
                return
            }

            if let error = error {
                Self.performCompletion(with: .failure(NetworkServiceError.error(error: error, data: data)),
                                       onMainThread: completeOnMainThread, completion: completion)
                return
            }

            guard let httpUrlResponse = response as? HTTPURLResponse else {
                Self.performCompletion(with: .failure(NetworkServiceError.nilHttpUrlResponse),
                                       onMainThread: completeOnMainThread, completion: completion)
                return
            }

            Self.performCompletion(with: .success((data, httpUrlResponse)), onMainThread: completeOnMainThread, completion: completion)
        }

        task.resume()
    }

    private static func handleResponse(urlResponse: URLResponse?,
                                       data: Data?,
                                       completeOnMainThread: Bool,
                                       completion: @escaping Completion) {
        if let httpUrlResponse = urlResponse as? HTTPURLResponse {
            Self.performCompletion(with: .failure(NetworkServiceError.statusCodeError(httpUrlResponse: httpUrlResponse, data: data)),
                                   onMainThread: completeOnMainThread,
                                   completion: completion)
        } else {
            Self.performCompletion(with: .failure(NetworkServiceError.nilHttpUrlResponse),
                                   onMainThread: completeOnMainThread,
                                   completion: completion)
        }

    }

    public func makeRequest<T>(networkRequest: NetworkRequestProtocol, type: T.Type,
                               completeOnMainThread: Bool = true, completion: @escaping DecodableCompletion<T>) where T: Decodable {
        makeRequest(networkRequest: networkRequest, completeOnMainThread: completeOnMainThread) { result in
            switch result {
            case .failure(let error):
                completion(.failure(error))
            case .success(let successResult):
                guard let data = successResult.data else {
                    completion(.failure(NetworkServiceError.nilDataError))
                    return
                }

                do {
                    let decodable = try self.jsonDecoder.decode(T.self, from: data)
                    completion(.success((decodable, successResult.httpUrlResponse)))
                } catch {
                    completion(.failure(NetworkServiceError.error(error: error, data: data)))
                }
            }
        }
    }

    public static let standardJsonDecoder: JSONDecoder = {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSSZ"
        let jsonDecoder = JSONDecoder()
        jsonDecoder.dateDecodingStrategy = .formatted(dateFormatter)
        return jsonDecoder
    }()

    private typealias CompletionResult = Result<SuccessResult<Data?>, NetworkServiceError>
    private static func performCompletion(with result: CompletionResult, onMainThread: Bool, completion: @escaping Completion) {
        if onMainThread {
            DispatchQueue.main.async { completion(result) }
        } else {
            completion(result)
        }
    }

    private func isSuccessful(statusCode: Int) -> Bool {
        if statusCode == 204 {
            return false
        }
        return (200...299).contains(statusCode)
    }
}
