//
//  FakeURLSession.swift
//  NetworkManager
//
//  Created by Alex Núñez on 09/04/2020.
//  Copyright © 2020 Alex Franco. All rights reserved.
//

import Foundation

public class FakeURLSession: URLSession {
	var responseCode: Int = 200
    var responseError: Error?
    var resourceData: Data?

	public required init(responseCode: Int, resourceData: Data?, responseError: Error?) {
		super.init()
		self.responseCode = responseCode
		self.resourceData = resourceData
		self.responseError = responseError
	}

	override public func dataTask(with request: URLRequest,
                                  completionHandler: @escaping (Data?, URLResponse?, Error?) -> Void) -> URLSessionDataTask {
        let response = HTTPURLResponse(url: request.url!, statusCode: responseCode, httpVersion: nil, headerFields: nil)
        completionHandler(resourceData, response, responseError)
        return FakeDataTask()
    }
}

public class FakeDataTask: URLSessionDataTask {
	override public func resume() {
        return
    }
}
