//
//  APIErrorType.swift
//  NetworkManager
//
//  Created by Alex Franco on 12/02/2020.
//  Copyright © 2020 Alex Franco. All rights reserved.
//

import Foundation

public enum APIError: Error {
    case urlFormatError
    case networkingError(Error)
    case serverError
    case requestError(Int, String)
    case invalidResponse
    case decodingError(DecodingError)
    case encodingError(Error)
    case errorResponse(APIResponse)
}
