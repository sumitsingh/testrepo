public enum NetworkServiceError: Error {
    case statusCodeError(httpUrlResponse: HTTPURLResponse, data: Data?)
    case error(error: Error, data: Data?)
    case nilDataError
    case nilHttpUrlResponse
}
