//
//  HTTPMethod.swift
//  CoopRest
//
//  Created by Andy Rennard on 06/08/2019.
//  Copyright © 2019 Coop. All rights reserved.
//

import Foundation

public enum HTTPMethod: String {
    case GET
    case POST
    case PUT
    case PATCH
    case DELETE
}
