import Foundation

class URLSessionMock: URLSession {
    let data: Data?
    let error: Error?
    let statusCode: Int

    init(data: Data?, statusCode: Int, error: Error?) {
        self.data = data
        self.statusCode = statusCode
        self.error = error
    }

    override func dataTask(with request: URLRequest, completionHandler: @escaping (Data?, URLResponse?, Error?) -> Void) -> URLSessionDataTask {
        URLSessionDataTaskMock { completionHandler(self.data, self.urlResponse(urlRequest: request), self.error) }
    }

    private func urlResponse(urlRequest: URLRequest) -> HTTPURLResponse? {
        HTTPURLResponse(url: urlRequest.url!,
                        statusCode: statusCode,
                        httpVersion: nil,
                        headerFields: urlRequest.allHTTPHeaderFields)
    }
}

class URLSessionDataTaskMock: URLSessionDataTask {
    let closure: () -> Void

    init(closure: @escaping () -> Void) {
        self.closure = closure
    }

    override func resume() {
        DispatchQueue.global().async { self.closure() }
    }
}
