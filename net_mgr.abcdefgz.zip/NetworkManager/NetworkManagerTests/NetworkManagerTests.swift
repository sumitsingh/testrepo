//
//  NetworkManagerTests.swift
//  NetworkManagerTests
//
//  Created by Alex Franco on 12/02/2020.
//  Copyright © 2020 Alex Franco. All rights reserved.
//

import XCTest
@testable import NetworkManager

class NetworkManagerTests: XCTestCase {
    func test_isHttpSuccessStatusCode_returnFalse_whenStatusCodeIsAbove299() {
        XCTAssertFalse(300.isHttpSuccessStatusCode())
    }

    func test_isHttpSuccessStatusCode_returnFalse_whenStatusCodeIsBelow200() {
        XCTAssertFalse(199.isHttpSuccessStatusCode())
    }

    func test_isHttpSuccessStatusCode_returnTrue_whenStatusCodeIs200() {
        XCTAssertTrue(200.isHttpSuccessStatusCode())
    }

}
