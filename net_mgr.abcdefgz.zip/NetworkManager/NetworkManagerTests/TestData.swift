@testable import NetworkManager

struct AbcNetworkRequest: NetworkRequestProtocol {
    let urlPaths: [String]
    let url: URL
    let cachePolicy: URLRequest.CachePolicy?
    let httpMethod: HTTPMethod
    let httpBody: Data?
    let httpHeaders: [RequestHeaderType]

    init() {
        urlPaths = []
        url = URL(string: "https://www.abc.com")!
        cachePolicy = nil
        httpMethod = .GET
        httpBody = nil
        httpHeaders = [RequestHeader.acceptApplicationJson,
                       RequestHeader.contentTypeApplicationJson,
                       RequestHeader.cacheControl]
    }

    init(urlPaths: [String],
         url: URL, cachePolicy: URLRequest.CachePolicy?,
         httpMethod: HTTPMethod, httpBody: Data?,
         httpHeaders: [RequestHeaderType]) {
        self.urlPaths = urlPaths
        self.url = url
        self.cachePolicy = cachePolicy
        self.httpMethod = httpMethod
        self.httpBody = httpBody
        self.httpHeaders = httpHeaders
    }
}

struct Address: Codable, Equatable {
    let stretName: String
    let houseNumber: String
    let postCode: String
}
