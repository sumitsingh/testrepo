import XCTest
@testable import NetworkManager

class NetworkServiceTests: XCTestCase {
    let abcNetworkRequest = AbcNetworkRequest()

    func test_makeRequest_returnsExpectedResponse_whenSuccessful() throws {
        let expectedResponseData = "A test data".data(using: String.Encoding.utf8)
        let urlSession = URLSessionMock(data: expectedResponseData, statusCode: 200, error: nil)
        let networkService = NetworkService(urlSession: urlSession)
        let expectation = self.expectation(description: "expectation")

        networkService.makeRequest(networkRequest: abcNetworkRequest) { response in
            switch response {
            case .failure(let error):
                XCTFail(error.localizedDescription)
            case .success(let successResult):
                XCTAssertEqual(successResult.data, expectedResponseData)
            }
            expectation.fulfill()
        }

        wait(for: [expectation], timeout: 1)
    }

    func test_makeRequest_returnsExpectedResponse_whenStatusCodeIsNot2xx() throws {
        let expectedResponseData = "A test data".data(using: String.Encoding.utf8)
        let urlSession = URLSessionMock(data: expectedResponseData, statusCode: 400, error: nil)
        let networkService = NetworkService(urlSession: urlSession)
        let expectation = self.expectation(description: "expectation")

        networkService.makeRequest(networkRequest: abcNetworkRequest) { response in
            if case let .failure(error) = response, case let .statusCodeError(httpUrlResponse, data) = error {
                XCTAssertEqual(httpUrlResponse.statusCode, 400)
                XCTAssertEqual(data, expectedResponseData)
            } else {
                XCTFail(".statusCodeError is expected")
            }
            expectation.fulfill()
        }

        wait(for: [expectation], timeout: 1)
    }

    func test_makeRequest_returnsExpectedResponse_whenErrorOccur() throws {
        let expectedResponseData = "A test data".data(using: String.Encoding.utf8)
        let expectedError = NSError(domain: "com.test", code: -999, userInfo: nil)
        let urlSession = URLSessionMock(data: expectedResponseData, statusCode: 200, error: expectedError)
        let networkService = NetworkService(urlSession: urlSession)
        let expectation = self.expectation(description: "expectation")

        networkService.makeRequest(networkRequest: abcNetworkRequest) { response in
            if case let .failure(serviceError) = response, case let .error(error, data) = serviceError {
                XCTAssertEqual(error as NSError, expectedError)
                XCTAssertEqual(data, expectedResponseData)
            } else {
                XCTFail(".statusCodeError is expected")
            }
            expectation.fulfill()
        }

        wait(for: [expectation], timeout: 1)
    }

    func test_makeRequest_returnsDecodedObject() throws {
        let expectedAddress = Address(stretName: "Balloon ", houseNumber: "1", postCode: "M60 4EP")
        let expectedResponseData = try self.endocode(object: expectedAddress)
        let urlSession = URLSessionMock(data: expectedResponseData, statusCode: 200, error: nil)
        let networkService = NetworkService(urlSession: urlSession)
        let expectation = self.expectation(description: "expectation")

        networkService.makeRequest(networkRequest: abcNetworkRequest, type: Address.self) { response in
            switch response {
            case .failure(let error):
                XCTFail(error.localizedDescription)
            case .success(let successResponse):
                XCTAssertEqual(successResponse.data, expectedAddress)
            }
            expectation.fulfill()
        }

        wait(for: [expectation], timeout: 1)
    }

    func test_makeRequest_returnsDecodedObject_whenDataIsNil() throws {
        let urlSession = URLSessionMock(data: nil, statusCode: 200, error: nil)
        let networkService = NetworkService(urlSession: urlSession)
        let expectation = self.expectation(description: "expectation")

        networkService.makeRequest(networkRequest: abcNetworkRequest, type: Address.self) { response in
            if case let .failure(serviceError) = response, case .nilDataError = serviceError {
                /* Do nothing. Expected condition */
            } else {
                XCTFail(".nilDataError expected")
            }
            expectation.fulfill()
        }

        wait(for: [expectation], timeout: 1)
    }

    func test_makeRequest_whenSuccessful_completionOnMainThreadIsTrue() throws {
        let expectedResponseData = "A test data".data(using: String.Encoding.utf8)
        let urlSession = URLSessionMock(data: expectedResponseData, statusCode: 200, error: nil)
        let networkService = NetworkService(urlSession: urlSession)
        let expectation = self.expectation(description: "expectation")

        networkService.makeRequest(networkRequest: abcNetworkRequest) { _ in
            XCTAssertEqual(Thread.current, Thread.main)
            expectation.fulfill()
        }

        wait(for: [expectation], timeout: 1)
    }

    func test_makeRequest_whenError_completionOnMainThreadIsTrue() throws {
        let urlSession = URLSessionMock(data: nil, statusCode: 999, error: nil)
        let networkService = NetworkService(urlSession: urlSession)
        let expectation = self.expectation(description: "expectation")

        networkService.makeRequest(networkRequest: abcNetworkRequest) { result in
            XCTAssertEqual(Thread.current, Thread.main)
            print(result)
            expectation.fulfill()
        }

        wait(for: [expectation], timeout: 1)
    }

    func test_makeRequest_successful_whenCompletionOnMainThreadIsFalse() throws {
        let expectedResponseData = "A test data".data(using: String.Encoding.utf8)
        let urlSession = URLSessionMock(data: expectedResponseData, statusCode: 200, error: nil)
        let networkService = NetworkService(urlSession: urlSession)
        let expectation = self.expectation(description: "expectation")

        networkService.makeRequest(networkRequest: abcNetworkRequest, completeOnMainThread: false) { _ in
            XCTAssertNotEqual(Thread.current, Thread.main)
            expectation.fulfill()
        }

        wait(for: [expectation], timeout: 1)
    }

    func test_makeRequest_whenError_completionOnMainThreadIsFalse() throws {
        let error = NSError(domain: "test.com", code: -1, userInfo: nil)
        let urlSession = URLSessionMock(data: nil, statusCode: 999, error: error)
        let networkService = NetworkService(urlSession: urlSession)
        let expectation = self.expectation(description: "expectation")

        networkService.makeRequest(networkRequest: abcNetworkRequest, completeOnMainThread: false) { _ in
            XCTAssertNotEqual(Thread.current, Thread.main)
            expectation.fulfill()
        }

        wait(for: [expectation], timeout: 1)
    }

    func createUrlResponse(with networkRequest: NetworkRequestProtocol, statusCode: Int) -> HTTPURLResponse? {
        let headerFields = ["Accept": "application/json", "Content-Type": "application/json"]
        let urlResponse = HTTPURLResponse(url: networkRequest.url,
                                               statusCode: statusCode,
                                               httpVersion: nil,
                                               headerFields: headerFields)

        return urlResponse
    }

    static func isUrlResponse(_ urlResponse: HTTPURLResponse, equal urlResponse2: HTTPURLResponse) -> Bool {
        return urlResponse.url == urlResponse2.url &&
        urlResponse.allHeaderFields as? [String: String] == urlResponse2.allHeaderFields as? [String: String]
    }

    func endocode<T: Encodable>(object: T) throws -> Data {
        return try JSONEncoder().encode(object)
    }
}
