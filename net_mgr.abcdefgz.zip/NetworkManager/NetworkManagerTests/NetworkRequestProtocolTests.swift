import XCTest
@testable import NetworkManager

class NetworkRequestProtocolTests: XCTestCase {
    func test_urlRequest_1() {
        let abcNetworkRequest = AbcNetworkRequest(urlPaths: ["accounts", "main"],
                                                  url: URL(string: "http://www.abc.com")!,
                                                  cachePolicy: nil,
                                                  httpMethod: .GET,
                                                  httpBody: nil,
                                                  httpHeaders: [RequestHeader.acceptApplicationJson,
                                                                RequestHeader.contentTypeApplicationJson])
        let urlRequest = abcNetworkRequest.urlRequest()

        XCTAssertEqual(urlRequest.url?.absoluteString, "http://www.abc.com/accounts/main")
        XCTAssertEqual(urlRequest.cachePolicy, .useProtocolCachePolicy)
        XCTAssertEqual(urlRequest.httpMethod, HTTPMethod.GET.rawValue)
        XCTAssertEqual(urlRequest.httpBody, nil)
    }

    func test_urlRequest_2() {
        let abcNetworkRequest = AbcNetworkRequest(urlPaths: ["cities", "Manchester"],
                                                  url: URL(string: "https://www.xyz.com")!,
                                                  cachePolicy: .returnCacheDataDontLoad,
                                                  httpMethod: .POST,
                                                  httpBody: "".data(using: .utf8),
                                                  httpHeaders: [])
        let urlRequest = abcNetworkRequest.urlRequest()

        XCTAssertEqual(urlRequest.url?.absoluteString, "https://www.xyz.com/cities/Manchester")
        XCTAssertEqual(urlRequest.cachePolicy, .returnCacheDataDontLoad)
        XCTAssertEqual(urlRequest.httpMethod, HTTPMethod.POST.rawValue)
        XCTAssertEqual(urlRequest.httpBody, "".data(using: .utf8))
    }
}
